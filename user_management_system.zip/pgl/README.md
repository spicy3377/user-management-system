## User management system

This is user management system  with admin panel


## Features
* Add records
* Delete Records
* Edit and View records
* See total statistics




## Logins
* admin
* 123456 

    or

* glory
* vampire

To access the user dashboard signup as a user or rather use this test acoount

* leo
* 123456


## Dependencies/Technologies
<details>
     <summary> Click to expand </summary>

* HTML5
* CSS and little bootsrap   
* Php 7
* Mysqli
    
</details>

## Screenshots


## Getting started 
* Download or clone the project or repo
* Make sure you have a xampp server
* import the database to your php admin ...you can fing the database file at this folder [sql/pgl.sql]
* now go to your localhost and type localhost/[name of the project]


## Directory Structure
<details>
     <summary> Click to expand </summary>
  
```

|   |-- css
|-- |   |--  bootstrap.css
|   |   |-- cp.css

|   |   db
|   |   |   |-- connection.php

|   |   includes
|   |   |   |   | addup.php
|   |   |   |   |-- del.php
|   |   |   |   |-- eddited.php
|   |   |   |   |   'pro.php

|--    find the rest of the directoories when you download the project
```

</details>
     
## Created & Maintained By

 Your boy japheth jonathan 

> If you found this project helpful or you learned something from the source code and want to thank me, consider buying me a cup of :coffee or some chicken burger:


